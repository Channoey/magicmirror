package com.sxf.magicmirror;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity implements View.OnClickListener {

    private WebView webView_getimg;
    private Button button_getimg;
    private ImageView imageView_back;
    private WebSettings webSettings;
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        webView_getimg = (WebView) findViewById(R.id.webView_getimg);
        button_getimg = (Button) findViewById(R.id.button_getimg);
        imageView_back = (ImageView) findViewById(R.id.imageView_back);
        button_getimg.setOnClickListener(this);
        imageView_back.setOnClickListener(this);

        webSettings = webView_getimg.getSettings();
        //设置自适应屏幕，两者合用
        webSettings.setUseWideViewPort(true); //将图片调整到适合webview的大小
        webSettings.setLoadWithOverviewMode(true); // 缩放至屏幕的大小

        webView_getimg.loadUrl("http://121.36.68.53/WEB/MagicMirror");
        webView_getimg.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button_getimg:
                webView_getimg.reload();
                Toast.makeText(DashboardActivity.this, "刷新成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.imageView_back:
                webView_getimg.destroy();
                finish();
            default:
                break;
        }
    }
}
