package com.sxf.magicmirror;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.UnsupportedEncodingException;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText editTextAdd;
    private TextView textViewLog;
    private Button buttonClearTextView;
    private Button buttonAdd;
    private Button buttonFlush;
    private Button buttonFinish;
    private Button buttonDashboard;
    private Spinner spinnerItems;
    private String SpItemSelected = null;
    ArrayAdapter<String> adapter;

    private MqttAndroidClient client;
    private String TAG = "MainActivity";
    private PahoMqttClient pahoMqttClient;

    private String MQTT_BROKER_URL = "tcp://121.36.68.53:1883";
    private String CLIENT_ID = "Magic_App";
    private String MQTT_CLIENT_UN = "";
    private String MQTT_CLIENT_PW = "";
    private String TOPIC_SUB = "/RaspberryPi/MagicMirror/AdrSub_MirPub/";
    private String TOPIC_PUB = "/RaspberryPi/MagicMirror/AdrPub_MirSub/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonClearTextView = (Button) findViewById(R.id.buttonClearTextView);
        buttonFlush = (Button) findViewById(R.id.buttonFlush);
        buttonFinish = (Button) findViewById(R.id.buttonFinish);
        editTextAdd = (EditText) findViewById(R.id.editTextAdd);
        textViewLog = (TextView) findViewById(R.id.textViewLog);
        spinnerItems = (Spinner) findViewById(R.id.spinnerItems);
        buttonDashboard =  (Button) findViewById(R.id.button_dashboard);
        adapter = new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item);
        spinnerItems.setAdapter(adapter);
        textViewLog.setMovementMethod(ScrollingMovementMethod.getInstance());
        buttonAdd.setOnClickListener(this);
        buttonClearTextView.setOnClickListener(this);
        buttonFlush.setOnClickListener(this);
        buttonFinish.setOnClickListener(this);
        buttonDashboard.setOnClickListener(this);

        pahoMqttClient = new PahoMqttClient();
        //Connect to Broker
        client = pahoMqttClient.getMqttClient(  getApplicationContext(),
                MQTT_BROKER_URL,
                CLIENT_ID,
                MQTT_CLIENT_UN,
                MQTT_CLIENT_PW
        );
        //Set Mqtt Message Callback
        mqttCallback();
    }

    // Called when a subscribed message is received
    protected void mqttCallback() {
        client.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                Log.i(TAG, "connectComplete");
                Toast.makeText(MainActivity.this, "MQTT连接成功！", Toast.LENGTH_SHORT).show();
                try {
                    pahoMqttClient.subscribe(client, TOPIC_SUB, 0);
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void connectionLost(Throwable throwable) {
                Log.i(TAG, "connectionLost: ");
                Toast.makeText(MainActivity.this, "MQTT连接断开！", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                if(topic.equals(TOPIC_SUB)) {
                    MqttMsgRevProcess(message.toString());
                }else {
                    String msg = "topic: " + topic + "\r\nMessage: " + message.toString() + "\r\n";
                    Log.i(TAG, msg);
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                Log.i(TAG, "deliveryComplete");
                Toast.makeText(MainActivity.this, "发送成功！", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void MqttMsgRevProcess(String message){
        Log.i(TAG, message);
        JSONObject msgObj = JSON.parseObject(message);
        String source = msgObj.getString("source");
        char clearFlag = 1;
        if(source.equals("mirror")){
            JSONArray content = msgObj.getJSONArray("content");
            AddTextViewLog(msgObj.toString());
            for (Object o : content) {
                JSONArray i = (JSONArray) o;
                String title = i.getJSONObject(0).getString("title");
                String msg = i.getJSONObject(0).getString("msg");
                System.out.println("title:" + title);
                System.out.println("msg:" + msg);
                if(title.equals("setMirrorToDoItems")){  // 将TODO项目添加到spinner
                    if(clearFlag==1){
                        adapter.clear();
                        clearFlag = 0;
                    }
                    if(!msg.isEmpty()){
                        adapter.add(msg);
                    }
                }
            }
        }
    }

    private void MqttMsgPubProcess(String title, String message){
        String inputText = String.format("{\"source\":\"app\", \"content\":[[{\"title\":\"%s\",\"msg\":\"%s\"}]]}",title,message);
        if(pahoMqttClient.mqttAndroidClient.isConnected()){
            try {
                pahoMqttClient.publishMessage(client, inputText, 0, TOPIC_PUB);
            } catch (MqttException | UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }else{
            Toast.makeText(MainActivity.this, "MQTT连接异常",Toast.LENGTH_SHORT).show();
        }
    }

    public void AddTextViewLog(String msg){
        textViewLog.append(String.format("%s\n\n",msg));
        int offset=textViewLog.getLineCount()*textViewLog.getLineHeight();
        if(offset>textViewLog.getHeight()){
            textViewLog.scrollTo(0,offset-textViewLog.getHeight());
        }
    }

    public void ClearTextViewLog(){
        if(textViewLog.getText() != null){
            textViewLog.setText(null);
            textViewLog.scrollTo(0,0);
            Toast.makeText(MainActivity.this, "清空成功！",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAdd:
                final String inputText = editTextAdd.getText().toString();
                if(!inputText.isEmpty()){
                    AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("提示");
                    dialog.setMessage("确认添加？");
                    dialog.setCancelable(true);
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            editTextAdd.setText(null);
                            MqttMsgPubProcess("addMirrorToDoItem", inputText);
                        }
                    });
                    dialog.show();
                }
                break;

            case R.id.buttonClearTextView:
                ClearTextViewLog();
                break;

            case R.id.buttonFlush:
                MqttMsgPubProcess("getMirrorToDoItems", " ");
                break;

            case R.id.buttonFinish:
                if(spinnerItems.getSelectedItem()!=null){
                    SpItemSelected = spinnerItems.getSelectedItem().toString();
                    AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("提示");
                    dialog.setMessage("确认已完成？");
                    dialog.setCancelable(true);
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            adapter.remove(SpItemSelected);
                            MqttMsgPubProcess("delMirrorToDoItem", SpItemSelected);
                            Toast.makeText(MainActivity.this, SpItemSelected, Toast.LENGTH_SHORT).show();
                        }
                    });
                    dialog.show();
                }
                break;
            case R.id.button_dashboard:
                System.out.println("button_dashboard");
                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }
}
